package com.cg.hms.dao;

import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.exception.HMSException;

public interface IAdminDao {
	int addHotel(Hotel hotel) throws HMSException;

	int deleteHotel(int hotelId) throws HMSException;
	
	int modifyHotel(int hotelId, String desc) throws HMSException;
	
	int addRoom(Room room) throws HMSException;
	
	int deleteRoom(int roomId) throws HMSException;
	
	int modifyRoomAvailability(int roomId, String value) throws HMSException;
	
	int modifyRoomRate(int roomId, int value) throws HMSException;



}
