package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.hms.bean.Room;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.DbUtil;

public class RoomDAOImpl implements IRoomDAO {

	@Override
	public List<Room> listRoom(int hcode, String rtype) throws HMSException {
		List<Room> roomList;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn.prepareStatement(IQueryMapper.LIST_ROOMS);)  {
			
			st.setInt(1, hcode);
			st.setString(2, rtype);
			ResultSet rs = st.executeQuery();
			roomList = new ArrayList<Room>();		
			while(rs.next()){
				Room room = new Room();
				room.setHotelId(rs.getInt(1));
				room.setRoomId(rs.getInt(2));
				room.setRoomType(rs.getString(4));
				room.setPerNightPrice(rs.getDouble(5));
				room.setAvailable(rs.getString(6));
//				hotel.setStatus(Status.valueOf(rs.getString("status")));	
				roomList.add(room);
			}
			
		} catch (SQLException e) {
//			log.error(e);
			throw new HMSException("Unable To Fetch roomdets");
		}
		return roomList;
	}

}
