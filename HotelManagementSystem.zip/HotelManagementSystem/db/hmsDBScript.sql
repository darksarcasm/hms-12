//sequence
create sequence seq_uid
start with 104
increment by 1 cache 104;

//Create User Table
CREATE TABLE users (userId varchar(4) PRIMARY KEY, 
password varchar(7),
role varchar(10), 
userName varchar(20) UNIQUE,
mobileNo varchar(10),
phone varchar(10),
address varchar(25), 
email varchar(15));

//Create Hotel Table
CREATE TABLE hotel (hotelId number(7),
city varchar(10),
hotelName varchar (20),
address varchar(25),
description varchar(50),
avgRatePerNight number(10,2),
phoneNo1 varchar(10),
phoneNo2 varchar(10),
rating varchar(6),
email varchar(15),
fax varchar(15));


//Create RoomDetails Table
CREATE TABLE roomdetails (hotelId number(4), 
roomId number(4) unique, 
roomNo number(3),
roomType varchar2(20),
perNightRate number(10,2),
availability varchar2(3));

//Create BookingDetails Table
CREATE TABLE bookingdetails (bookingId number(4),
roomId number(4),
userId number(4),
bookedFrom date,
bookedTo date,
noofadults number(3),
noofchildren number(3),
amount number(10,2));

//Insert into Users
INSERT INTO users (userId, userName, password, role) values ('101','Admin','admin','admin');
INSERT INTO users (userId, userName, password, role) values ('102','Customer','cust','customer');
INSERT INTO users (userId, userName, password, role) values ('103','Employee','empl','employee');

//Insert into Hotel Table
INSERT INTO Hotel (hotelId, hotelName, city, address, description, avgRatePerNight ,phoneno1, phoneno2, rating, email, fax) values (1001,'Marriot','Bangalore','address','description',7000 ,'phone01', 'phone02','5','email', 'fax');
INSERT INTO Hotel (hotelId, hotelName, city, address, description, avgRatePerNight ,phoneno1, phoneno2, rating, email, fax) values (1002,'Radisson','Hyderabad','address','description',3000 ,'phone01', 'phone02','4','email', 'fax');
INSERT INTO Hotel (hotelId, hotelName, city, address, description, avgRatePerNight ,phoneno1, phoneno2, rating, email, fax) values (1003,'TAJ','Bangalore','address','description',6000 ,'phone01', 'phone02','5','email', 'fax');


INSERT INTO Hotel (hotelId, hotelName, city) values (1002,'TAJ','Mumbai');
INSERT INTO Hotel (hotelId, hotelName, city) values (1003,'Trident','Mumbai');

//Insert into RoomDetails
insert into roomdetails values(1001,201,301,'AC',6000,'Yes');
insert into roomdetails values(1001,202,302,'AC',6000,'Yes');
insert into roomdetails values(1001,203,401,'Non-AC',4000,'Yes');
insert into roomdetails values(1001,204,402,'Delux AC',8000,'Yes');
